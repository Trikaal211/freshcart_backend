import express from "express";
import cors from "cors"; // 👈 CORS import
import "../config/db.js"
import router from "./routers/index.router.js"; // central router
import cartrouter from "./routers/cart.router.js";

const app = express();

// Middleware
app.use(cors()); // 👈 CORS enable
app.use(express.json());
app.use("/cart",cartrouter );
app.use("/", router);

app.listen(3000, () => {
  console.log("hey");
});
