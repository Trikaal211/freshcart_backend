import express from "express";
import categoryRouter from "./catagory.router.js";
import productRouter from "./product.router.js";
const router = express.Router();

// Mount individual routers
router.use("/categories", categoryRouter);
router.use("/products", productRouter);

// Future: router.use("/products", productRouter);

export default router;
