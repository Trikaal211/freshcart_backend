import Cart from "../../schema/shopping.model.js";

// Add product to cart
export const addToCart = async (req, res) => {
  const { productId, quantity = 1 } = req.body;

  try {
    let cart = await Cart.findOne();

    if (!cart) {
      cart = await Cart.create({ products: [] });
    }

    const existing = cart.products.find(
      (p) => p.productId.toString() === productId
    );

    if (existing) {
      existing.quantity += quantity; // increment quantity
    } else {
      cart.products.push({ productId, quantity });
    }

    await cart.save();
    res.status(200).json(cart);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Server error" });
  }
};

// Get cart
export const getCart = async (req, res) => {
  try {
    const cart = await Cart.findOne().populate("products.productId");
    if (!cart) return res.status(404).json({ message: "Cart is empty" });
    res.status(200).json(cart);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Server error" });
  }
};

// Remove an item from cart
// Usage:
//  DELETE /cart/:cartItemId           -> remove by cart array _id (recommended)
//  DELETE /cart?productId=xxxxx      -> remove by productId (if you prefer)
export const removeFromCart = async (req, res) => {
  const { cartItemId } = req.params;
  const { productId } = req.query;

  try {
    // Find existing cart (no user implemented yet)
    let cart = await Cart.findOne();
    if (!cart) return res.status(404).json({ message: "Cart not found" });

    if (cartItemId) {
      // Remove by subdocument _id
      const updated = await Cart.findOneAndUpdate(
        { "products._id": cartItemId },
        { $pull: { products: { _id: cartItemId } } },
        { new: true }
      ).populate("products.productId");

      if (!updated) return res.status(404).json({ message: "Cart item not found" });
      return res.status(200).json(updated);
    } else if (productId) {
      // Remove by productId
      const updated = await Cart.findOneAndUpdate(
        {},
        { $pull: { products: { productId } } },
        { new: true }
      ).populate("products.productId");

      // Even if no change, return updated cart or message
      return res.status(200).json(updated || { message: "Cart updated" });
    } else {
      return res.status(400).json({ error: "Provide cartItemId (param) or productId (query)" });
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Server error" });
  }
};
